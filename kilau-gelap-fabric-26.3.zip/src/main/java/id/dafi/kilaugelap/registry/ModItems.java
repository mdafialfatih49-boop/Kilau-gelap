package id.dafi.kilaugelap.registry;

import id.dafi.kilaugelap.KilauGelap;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;

import java.util.function.Function;

public final class ModItems {
    public static final Item HOLY_FEATHER = register("holy_feather", Item::new);
    public static final Item ESSENCE_OF_LIGHT = register("essence_of_light", Item::new);
    public static final Item DEMON_HORN = register("demon_horn", Item::new);
    public static final Item NETHER_ASH = register("nether_ash", Item::new);

    private ModItems() {}

    private static Item register(String name, Function<Item.Properties, Item> factory) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, KilauGelap.id(name));
        Item item = factory.apply(new Item.Properties().setId(key).stacksTo(64));
        return Registry.register(BuiltInRegistries.ITEM, key, item);
    }

    public static void initialize() {
        // Memuat kelas ini agar seluruh item di atas terdaftar.
    }
}
