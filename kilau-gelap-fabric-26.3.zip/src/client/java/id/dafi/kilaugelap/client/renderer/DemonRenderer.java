package id.dafi.kilaugelap.client.renderer;

import id.dafi.kilaugelap.KilauGelap;
import id.dafi.kilaugelap.client.model.DemonModel;
import id.dafi.kilaugelap.client.model.ModEntityModelLayers;
import id.dafi.kilaugelap.entity.DemonEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.Identifier;

public class DemonRenderer extends MobRenderer<DemonEntity, LivingEntityRenderState, DemonModel> {
    private static final Identifier TEXTURE = KilauGelap.id("textures/entity/demon.png");

    public DemonRenderer(EntityRendererProvider.Context context) {
        super(context, new DemonModel(context.bakeLayer(ModEntityModelLayers.DEMON)), 0.4F);
    }

    @Override
    public LivingEntityRenderState createRenderState() {
        return new LivingEntityRenderState();
    }

    @Override
    public Identifier getTextureLocation(LivingEntityRenderState state) {
        return TEXTURE;
    }
}
