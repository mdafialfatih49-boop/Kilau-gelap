package id.dafi.kilaugelap.registry;

import id.dafi.kilaugelap.KilauGelap;
import id.dafi.kilaugelap.entity.AngelEntity;
import id.dafi.kilaugelap.entity.DemonEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

public final class ModEntities {
    private static final ResourceKey<EntityType<?>> ANGEL_KEY = entityKey("angel");
    private static final ResourceKey<EntityType<?>> DEMON_KEY = entityKey("demon");

    public static final EntityType<AngelEntity> ANGEL = Registry.register(
            BuiltInRegistries.ENTITY_TYPE,
            ANGEL_KEY,
            EntityType.Builder.<AngelEntity>of(AngelEntity::new, MobCategory.CREATURE)
                    .sized(0.75F, 1.85F)
                    .build(ANGEL_KEY)
    );

    public static final EntityType<DemonEntity> DEMON = Registry.register(
            BuiltInRegistries.ENTITY_TYPE,
            DEMON_KEY,
            EntityType.Builder.<DemonEntity>of(DemonEntity::new, MobCategory.CREATURE)
                    .sized(0.8F, 1.9F)
                    .build(DEMON_KEY)
    );

    private ModEntities() {}

    private static ResourceKey<EntityType<?>> entityKey(String name) {
        return ResourceKey.create(Registries.ENTITY_TYPE, KilauGelap.id(name));
    }

    public static void initialize() {
        FabricDefaultAttributeRegistry.register(ANGEL, AngelEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(DEMON, DemonEntity.createAttributes());
    }
}
